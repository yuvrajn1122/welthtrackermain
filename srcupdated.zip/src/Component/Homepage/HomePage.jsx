import React from 'react';

const HomePage = () => {
    return (
        <div>
            <iframe src="/myTrckAssistantLandingPage/index.html" style={{ width: '100%', height: '100vh', border: 'none' }}></iframe>
        </div>
    );
};

export default HomePage;
